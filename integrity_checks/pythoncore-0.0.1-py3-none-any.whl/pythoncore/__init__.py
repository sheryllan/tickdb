name = 'pythoncore'

