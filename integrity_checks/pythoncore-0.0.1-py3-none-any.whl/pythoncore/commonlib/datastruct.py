from enum import Enum, EnumMeta
from .iterations import find_first_n, to_iter


def add_metaclass(metaclass):
    """Class decorator for creating a Enum class with a metaclass."""
    def wrapper(cls):
        orig_vars = metaclass.__prepare__(cls.__name__, cls.__bases__)
        excl_attrs = to_iter(cls.__dict__.get('__slots__')) + ['__dict__', '__weakref__']
        orig_vars.update({k: v for k, v in cls.__dict__.items() if k not in excl_attrs})
        return metaclass(cls.__name__, cls.__bases__, orig_vars)
    return wrapper


class InheritableEnumMeta(EnumMeta):
    @classmethod
    def __prepare__(metacls, cls, bases):
        base = [find_first_n(bases, lambda b: issubclass(b, Enum) and (not b._member_names_))]
        return super().__prepare__(cls, base)

    def __call__(cls, value=None, names=None, *, module=None, qualname=None, type=None, start=1):
        """Convenience method to create a new Enum class.
        :param value: Enum/str, the Enum name for creation or the Enum value for lookup
        :param names: the names of new members
                * An iterable of (member name, value) pairs.
                * A mapping of member name -> value pairs.
                """
        if names is None:  # simple value lookup
            return cls.__new__(cls, value)

        last_values = cls.values()
        start = last_values[-1] if last_values else start

        members = {k: v.value for k, v in cls.__members__.items()}
        new_members = names
        if isinstance(names, str):
            names = names.replace(',', ' ').split()
        if isinstance(names, (tuple, list)) and names and isinstance(names[0], str):
            if not hasattr(cls, '_generate_next_value_'):
                raise NotImplementedError("""The Enum class is missing method <_generate_next_value_> 
                for auto member value plug-in for names""")

            new_members = {}
            for count, name in enumerate(names):
                nval = cls._generate_next_value_(name, start, count, last_values)
                new_members[name] = nval
                last_values.append(nval)

        members.update(new_members)
        base = find_first_n(cls.mro(), lambda b: issubclass(b, Enum) and (not b._member_names_))
        if not base:
            raise TypeError(f'Type {cls} does not have Enum-like parent with empty member')

        base = add_metaclass(cls.__class__)(base) if base.__class__ != cls.__class__ else base
        return base._create_(value, members, module=module, qualname=qualname, type=type, start=start)

    def names(cls):
        return list(cls.__members__.keys())

    def values(cls):
        return [v.value for v in cls.__members__.values()]


class StrEnum(str, Enum):
    def __str__(self):
        return self._value_
