import pandas as pd
import numpy as np
import datetime as dt


def validate_time(time):
    """Validates the input time and returns a datetime.time object
        :param time: can be an object of:

                * A str
                * A tuple/list of ints
                * A timedelta/time
    """
    if isinstance(time, str):
        return pd.to_datetime(time).time()
    elif isinstance(time, (tuple, list)):
        return dt.time(*time)
    elif isinstance(time, dt.timedelta):
        return (dt.datetime.min + time).time()
    elif isinstance(time, dt.time):
        return time
    else:
        raise TypeError('Invalid time type: must be type of str, tuple/list, or datetime.time/timedelta')


def to_tz_datetime(date, time=None, from_tz=None, to_tz=None, to_orig=True):
    """Converts datetime from one timezone to another timezone

        :param date: datetime/date/str
        :param time: any valid type accepted by validate_time()
        :param from_tz: pytz.timezone
        :param to_tz: pytz.timezone
        :param to_orig: bool, whether cast the returned to the type of [date] if possible, set
        False to return a pandas.Timestamp object anyways

        :return: an object of pandas.Timestamp/datetime.datetime
    """

    if date is None:
        return

    dttm = pd.to_datetime(date)
    if time is not None:
        delta = pd.to_timedelta(validate_time(time).isoformat())
        dttm = dttm.normalize() + delta

    if dttm.tz is not None and from_tz is not None and dttm.tz != from_tz:
        raise ValueError('Conflicting timezones: parameter [date].tzinfo and [from-tz] are both defined yet diff')

    dttm = dttm.tz_localize(None).tz_localize(from_tz) if from_tz is not None else dttm
    result = dttm.tz_convert(to_tz) if dttm.tz is not None else dttm.tz_localize(to_tz)

    if to_orig and type(date) == dt.datetime:
        result = result.to_pydatetime()
    return result


def mask_between(timeseries, date_from=None, date_to=None, time_from=None, time_to=None,
                 weekmask=(0, 1, 2, 3, 4), tz=None, include_from=True, include_to=True):
    """ Gets a mask of the pandas.DatetimeIndex according to whether the time is within the specified date, time
        and week range.

    :param timeseries: iterable, the time series for masking
    :param date_from: datetime/date/str, the start datetime/date
    :param date_to: datetime/date/str, the end datetime/date
    :param time_from: any valid type accepted by validate_time(), the start time of each date
    :param time_to: any valid type accepted by validate_time(), the end time of each date
    :param weekmask: tuple, ints representing day of week (Monday=0, Sunday=6)
    :param tz: pytz.timezone, the timezone for all the datetime parameters
    :return: numpy.ndarray(bool)
    """

    dtfrom = to_tz_datetime(date_from, to_tz=tz)
    dtto = to_tz_datetime(date_to, to_tz=tz)

    weekmask_num = sum(2 ** x for x in weekmask)
    return np.fromiter(
        (
            (2 ** x.weekday & weekmask_num) and
            is_between(x, dtfrom, dtto, include_from, include_to) and
            is_between(x, time_from, time_to, include_from, include_to)
            for x in timeseries
         ),
        np.bool)


def is_between(value, start=None, end=None, include_start=True, include_end=True):
    """ Checks if the time value is between the time of start and end

    :param value: any valid type accepted by validate_time(), the time to be compared
    :param start: any valid type accepted by validate_time(), start time
    :param end: any valid type accepted by validate_time(), end time
    :param include_start: bool, default True
    :param include_end: bool, default True
    :return: bool
    """

    left, right = True, True
    try:
        value = pd.to_datetime(value)
        start, end = to_tz_datetime(start, to_tz=value.tz), to_tz_datetime(end, to_tz=value.tz)
    except TypeError:
        value = validate_time(value)
        start, end = validate_time(start), validate_time(end)
        if not (value.tzinfo == start.tzinfo == end.tzinfo):
            raise ValueError('Inconsistent timezone: comparison between time must have the same tzinfo')

    if start is not None:
        left = value >= start if include_start else value > start

    if end is not None:
        right = value <= end if include_end else value < end

    return left and right
