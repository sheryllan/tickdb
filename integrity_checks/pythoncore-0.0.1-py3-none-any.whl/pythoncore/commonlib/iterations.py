from collections import Iterable


def nontypes_iterable(arg, excl_types=(str,)):
    """ Checks if an arg is an iterable type except types in excl_types

    :param arg: any
    :param excl_types: tuple, types to exclude
    :return: bool
    """

    return isinstance(arg, Iterable) and not isinstance(arg, excl_types)


def to_iter(x, excl_types=(str,), ittype=list, dtype=None):
    """ Converts an object to an iterable type

    :param x: the object to be converted
    :param excl_types: tuple, types to exclude
    :param ittype: type/func, the returned type, default list
    :param dtype: type/func, the type of the data inside of the collection,
    default None without changing its original type
    :return: ittype type of iterable
    """

    x_iter = [x] if not nontypes_iterable(x, excl_types) else x
    return ittype(x_iter if dtype is None else map(dtype, x_iter))


def find_first_n(arry, condition, n=1):
    """ Finds the first n items that meets the condition

    :param arry: iterable
    :param condition: lambda function
    :param n: int, default 1
    :return: list if n > 1 or the item if n = 1
    """

    n = n if isinstance(n, int) else float('nan')
    result = list()
    for a in arry:
        if n <= 0:
            break
        if condition(a):
            result.append(a)
            n -= 1
    return result if len(result) != 1 else result[0]


def flatten_iter(items, level=None, excl_types=(str,)):
    """ Flattens the iterable for items that are not an object of excl_types

    :param items: iterable
    :param level: int, the top level of the item, default None
    :param excl_types: tuple, types to exclude
    :return: generator, if level is not None yield both level and the item
    """

    if nontypes_iterable(items, excl_types):
        level = None if level is None else level + 1
        for sublist in items:
            yield from flatten_iter(sublist, level, excl_types)
    else:
        level_item = items if level is None else (level - 1, items)
        yield level_item
